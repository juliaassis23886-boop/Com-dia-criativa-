"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Smile, Brain, BookOpen, Lock, Unlock, QrCode, LogIn, LogOut, User } from "lucide-react"

export default function ComedyEducationalSite() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [hasPaidAccess, setHasPaidAccess] = useState(false)

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (email && password) {
      setIsLoggedIn(true)
    }
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setEmail("")
    setPassword("")
  }

  const freeJokes = [
    "Por que os pássaros voam para o sul no inverno? Porque é longe demais para ir andando!",
    "O que o pato disse para a pata? Vem quá!",
    "Por que o livro de matemática estava triste? Porque tinha muitos problemas!",
    "O que é que a impressora falou para a outra impressora? Essa folha é sua ou é impressão minha?",
    "Por que o café foi ao médico? Porque estava passando mal!",
    "O que o Big Ben falou para o Big Mac? Nossa, como você engordou!",
    "Por que a plantinha não fala? Porque ela é muda!",
    "O que é que o cavalo foi fazer no orelhão? Passar um trote!",
    "Por que o elefante não usa computador? Porque tem medo do mouse!",
    "O que é que a fechadura falou para a chave? Vamos dar uma voltinha?",
    "Por que o galo canta de manhã? Porque de noite ele está dormindo!",
    "O que é que o peixe falou quando bateu na parede? Aaaau!",
    "Por que a galinha atravessa a rua? Para chegar do outro lado!",
    "O que é que tem no meio do ovo? A letra V!",
    "Por que o bombeiro não gosta de andar? Porque ele prefere correr atrás do fogo!",
    "O que é que o tomate foi fazer no banco? Tirar extrato!",
    "Por que o passarinho foi ao dentista? Para fazer um tratamento de canal!",
    "O que é que a lua falou para o sol? Você é muito quente para mim!",
    "Por que o computador foi ao médico? Porque estava com vírus!",
    "O que é que o zero falou para o oito? Que cinto maneiro!",
    "Por que a vaca foi ao espaço? Para ver a Via Láctea!",
    "O que é que o papel falou para a caneta? Pare de me riscar!",
    "Por que o relógio foi ao psicólogo? Porque estava com problemas de tempo!",
    "O que é que a televisão falou para o controle remoto? Você me controla demais!",
    "Por que o sapato foi ao médico? Porque estava com chulé!",
    "O que é que o açúcar falou para o café? Você me deixa doce!",
    "Por que a borracha foi embora? Porque estava cansada de apagar os erros dos outros!",
    "O que é que o espelho falou para a pessoa? Você está se vendo!",
    "Por que o lápis foi ao barbeiro? Para fazer a ponta!",
    "O que é que a porta falou para a chave? Você é a chave do meu coração!",
  ]

  const freeRiddles = [
    { question: "O que é que quanto mais se tira, maior fica?", answer: "O buraco" },
    { question: "O que é que tem coroa mas não é rei?", answer: "O abacaxi" },
    { question: "O que é que sobe quando a chuva desce?", answer: "O guarda-chuva" },
    { question: "O que é que tem dentes mas não morde?", answer: "O pente" },
    { question: "O que é que quanto mais cresce, menos se vê?", answer: "A escuridão" },
    { question: "O que é que tem pescoço mas não tem cabeça?", answer: "A garrafa" },
    { question: "O que é que anda com os pés na cabeça?", answer: "O piolho" },
    { question: "O que é que tem olhos mas não vê?", answer: "A batata" },
    { question: "O que é que nasce grande e morre pequeno?", answer: "O lápis" },
    { question: "O que é que tem boca mas não fala?", answer: "O rio" },
    { question: "O que é que quanto mais limpo, mais sujo fica?", answer: "A água" },
    { question: "O que é que tem cabeça mas não pensa?", answer: "O alho" },
    { question: "O que é que sobe mas nunca desce?", answer: "A idade" },
    { question: "O que é que tem pernas mas não anda?", answer: "A mesa" },
    { question: "O que é que quanto mais se corta, maior fica?", answer: "O cabelo" },
    { question: "O que é que tem orelhas mas não ouve?", answer: "A panela" },
    { question: "O que é que quanto mais quente, mais fresco fica?", answer: "O pão" },
    { question: "O que é que tem braços mas não abraça?", answer: "A cadeira" },
    { question: "O que é que quanto mais velho, mais novo fica?", answer: "O calendário" },
    { question: "O que é que tem língua mas não fala?", answer: "O sapato" },
    { question: "O que é que quanto mais se usa, mais novo fica?", answer: "O caminho" },
    { question: "O que é que tem asas mas não voa?", answer: "O moinho" },
    { question: "O que é que quanto mais se divide, mais se multiplica?", answer: "O conhecimento" },
    { question: "O que é que tem raiz mas não é planta?", answer: "O dente" },
    { question: "O que é que quanto mais se empresta, mais se tem?", answer: "A amizade" },
    { question: "O que é que tem casa mas não mora nela?", answer: "O caracol" },
    { question: "O que é que quanto mais se gasta, mais se economiza?", answer: "A saúde" },
    { question: "O que é que tem sede mas não bebe?", answer: "A planta" },
    { question: "O que é que quanto mais se procura, menos se acha?", answer: "O defeito" },
    { question: "O que é que tem coração mas não bate?", answer: "A alcachofra" },
  ]

  const folkloreStories = [
    {
      title: "Curupira",
      content:
        "O Curupira é um dos personagens mais conhecidos do folclore brasileiro. É descrito como um menino de cabelos vermelhos e pés virados para trás. Ele protege as florestas e os animais dos caçadores e lenhadores. Quando alguém se perde na mata, geralmente é obra do Curupira, que confunde as pessoas fazendo-as andar em círculos.",
    },
    {
      title: "Saci-Pererê",
      content:
        "O Saci-Pererê é um moleque travesso de uma perna só, que usa um gorro vermelho e está sempre com um cachimbo na boca. Ele adora fazer travessuras, como esconder objetos, fazer tranças no rabo dos cavalos e assustar viajantes. Diz a lenda que ele mora dentro de redemoinhos de vento.",
    },
    {
      title: "Iara",
      content:
        "Iara, também conhecida como Mãe d'Água, é uma sereia que vive nos rios da Amazônia. Ela tem metade do corpo de mulher e metade de peixe. Com seu canto melodioso, ela atrai os pescadores para o fundo dos rios. Quem consegue escapar de seus encantos fica louco.",
    },
    {
      title: "Boitatá",
      content:
        "O Boitatá é uma cobra de fogo gigante que protege as matas e os campos contra aqueles que provocam queimadas. Seus olhos são como faróis que brilham na escuridão. Ele persegue e devora quem destrói a natureza, especialmente durante a noite.",
    },
    {
      title: "Mula sem Cabeça",
      content:
        "A Mula sem Cabeça é uma mulher que foi amaldiçoada por ter se relacionado com um padre. Nas noites de quinta para sexta-feira, ela se transforma em uma mula que corre pelos campos soltando fogo pelas narinas. Para quebrar a maldição, é preciso tirar o freio de sua boca.",
    },
    {
      title: "Lobisomem",
      content:
        "O Lobisomem é um homem que se transforma em lobo nas noites de lua cheia. Geralmente é o sétimo filho homem de uma família. Durante a transformação, ele perde a consciência humana e sai correndo pelos campos. Para quebrar a maldição, alguém deve feri-lo com objeto de prata.",
    },
    {
      title: "Cuca",
      content:
        "A Cuca é uma velha feia com cabeça de jacaré que rouba crianças desobedientes. Ela mora numa caverna e nunca dorme. A Cuca é muito esperta e usa sua inteligência para capturar suas vítimas. É uma das figuras mais temidas pelas crianças brasileiras.",
    },
    {
      title: "Boto Cor-de-Rosa",
      content:
        "O Boto Cor-de-Rosa é um golfinho que se transforma em um homem bonito e elegante nas noites de festa junina. Ele seduz as mulheres e depois desaparece, voltando para o rio. Muitas vezes é responsabilizado por gravidezes misteriosas na região amazônica.",
    },
    {
      title: "Matinta Perera",
      content:
        "A Matinta Perera é uma velha que se transforma em pássaro durante a noite. Ela voa sobre as casas fazendo um assobio característico que anuncia desgraças. Para afastá-la, as pessoas deixam fumo de rolo na janela, pois ela adora fumar.",
    },
    {
      title: "Negrinho do Pastoreio",
      content:
        "O Negrinho do Pastoreio era um menino escravo que foi castigado injustamente por seu senhor cruel. Após sua morte, ele se tornou um espírito protetor que ajuda a encontrar objetos perdidos. Basta acender uma vela e pedir sua ajuda que ele atenderá ao pedido.",
    },
  ]

  const pixCode =
    "00020126330014br.gov.bcb.pix0111126332256595204000053039865802BR5920JULIA AGATA DE ASSIS6005ARAXA62070503***6304FD01"

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Smile className="h-8 w-8" />
              <h1 className="text-2xl font-bold">ComédiaBR Educativa</h1>
            </div>

            {!isLoggedIn ? (
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="secondary" className="flex items-center space-x-2">
                    <LogIn className="h-4 w-4" />
                    <span>Entrar</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Fazer Login</DialogTitle>
                    <DialogDescription>Entre com seu email e senha para acessar o conteúdo premium</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="password">Senha</Label>
                      <Input
                        id="password"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full">
                      Entrar
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            ) : (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <User className="h-4 w-4" />
                  <span>Bem-vindo!</span>
                </div>
                <Button variant="secondary" onClick={handleLogout}>
                  <LogOut className="h-4 w-4 mr-2" />
                  Sair
                </Button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-foreground mb-4">Diversão e Aprendizado Juntos! 🎭📚</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Descubra piadas hilariantes, desafie sua mente com charadas e mergulhe nas histórias fascinantes do folclore
            brasileiro. Conteúdo gratuito e premium disponível!
          </p>
        </div>

        <Tabs defaultValue="jokes" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="jokes" className="flex items-center space-x-2">
              <Smile className="h-4 w-4" />
              <span>Piadas</span>
            </TabsTrigger>
            <TabsTrigger value="riddles" className="flex items-center space-x-2">
              <Brain className="h-4 w-4" />
              <span>Charadas</span>
            </TabsTrigger>
            <TabsTrigger value="folklore" className="flex items-center space-x-2">
              <BookOpen className="h-4 w-4" />
              <span>Folclore</span>
            </TabsTrigger>
          </TabsList>

          {/* Jokes Section */}
          <TabsContent value="jokes">
            <div className="space-y-6">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-foreground mb-2">Piadas Brasileiras</h3>
                <p className="text-muted-foreground">30 piadas grátis + 100 piadas premium</p>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {freeJokes.map((joke, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center justify-between">
                        <span>Piada #{index + 1}</span>
                        <Badge variant="secondary">
                          <Unlock className="h-3 w-3 mr-1" />
                          Grátis
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm">{joke}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Premium Jokes Section */}
              <Card className="border-primary/20 bg-gradient-to-r from-primary/5 to-secondary/5">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Lock className="h-5 w-5 text-primary" />
                    <span>100 Piadas Premium</span>
                  </CardTitle>
                  <CardDescription>Desbloqueie mais 100 piadas exclusivas e hilariantes!</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold">R$ 9,90</span>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="bg-primary hover:bg-primary/90">
                          <QrCode className="h-4 w-4 mr-2" />
                          Pagar com PIX
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Pagamento PIX - Piadas Premium</DialogTitle>
                          <DialogDescription>
                            Escaneie o QR Code abaixo para pagar R$ 9,90 e desbloquear 100 piadas premium
                          </DialogDescription>
                        </DialogHeader>
                        <div className="text-center space-y-4">
                          <div className="bg-white p-4 rounded-lg inline-block">
                            <div className="text-xs font-mono break-all bg-gray-100 p-2 rounded">{pixCode}</div>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Após o pagamento, o acesso será liberado automaticamente
                          </p>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Riddles Section */}
          <TabsContent value="riddles">
            <div className="space-y-6">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-foreground mb-2">Charadas Inteligentes</h3>
                <p className="text-muted-foreground">30 charadas grátis + 100 charadas premium</p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                {freeRiddles.map((riddle, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center justify-between">
                        <span>Charada #{index + 1}</span>
                        <Badge variant="secondary">
                          <Unlock className="h-3 w-3 mr-1" />
                          Grátis
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="font-medium">{riddle.question}</p>
                      <details className="cursor-pointer">
                        <summary className="text-sm text-primary hover:text-primary/80">Ver resposta</summary>
                        <p className="text-sm text-muted-foreground mt-2 font-medium">{riddle.answer}</p>
                      </details>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Premium Riddles Section */}
              <Card className="border-secondary/20 bg-gradient-to-r from-secondary/5 to-primary/5">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Lock className="h-5 w-5 text-secondary" />
                    <span>100 Charadas Premium</span>
                  </CardTitle>
                  <CardDescription>Desafie sua mente com mais 100 charadas exclusivas!</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold">R$ 7,90</span>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="bg-secondary hover:bg-secondary/90">
                          <QrCode className="h-4 w-4 mr-2" />
                          Pagar com PIX
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Pagamento PIX - Charadas Premium</DialogTitle>
                          <DialogDescription>
                            Escaneie o QR Code abaixo para pagar R$ 7,90 e desbloquear 100 charadas premium
                          </DialogDescription>
                        </DialogHeader>
                        <div className="text-center space-y-4">
                          <div className="bg-white p-4 rounded-lg inline-block">
                            <div className="text-xs font-mono break-all bg-gray-100 p-2 rounded">{pixCode}</div>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Após o pagamento, o acesso será liberado automaticamente
                          </p>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Folklore Section */}
          <TabsContent value="folklore">
            <div className="space-y-6">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-foreground mb-2">Folclore Brasileiro</h3>
                <p className="text-muted-foreground">10 histórias fascinantes do nosso folclore</p>
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                {folkloreStories.map((story, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>{story.title}</span>
                        <Badge variant="outline">
                          <Unlock className="h-3 w-3 mr-1" />
                          Grátis
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm leading-relaxed">{story.content}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-secondary text-secondary-foreground mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center space-y-4">
            <h3 className="text-xl font-bold">ComédiaBR Educativa</h3>
            <p className="text-sm opacity-90">Diversão e aprendizado para toda a família brasileira</p>
            <div className="flex justify-center space-x-4 text-sm">
              <span>© 2024 ComédiaBR</span>
              <span>•</span>
              <span>Todos os direitos reservados</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
